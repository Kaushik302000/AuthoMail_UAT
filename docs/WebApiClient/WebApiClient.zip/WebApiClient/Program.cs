﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Refit;
using System.Net.Http;
using System.Threading;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using AM.USPSLib;
using System.Net;
using System.IO;
using System.Configuration;

namespace WebApiClient
{
    class Program
    {
        static string endpoint = ConfigurationManager.AppSettings["url"]; //"https://authomailuat.corelogic.com/";
        static void Main(string[] args)
        {
            if (endpoint.StartsWith("https", StringComparison.CurrentCultureIgnoreCase))
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            }

            string uid = ConfigurationManager.AppSettings["uid"];
            string pass = ConfigurationManager.AppSettings["pass"];

            var svc = RestService.For<IUSPS>(new HttpClient(new AuthenticatedHttpClientHandler(uid, pass)) { BaseAddress = new Uri(endpoint) });

            var result = svc.VerifyAddressAsync(new VerifierAddressRequest()
            {
                AddressRequests = new List<AddressRequest> { 
                    new AddressRequest { Id = "2", StreetAddress = "20 FLORENCE STREET P.O. BOX 421", City = "MARLBOROUGH", State = "MA", Zip5 = "01757" },
                    //new AddressRequest { Id = "3", StreetAddress = "PO BOX 3200", City = "LANGLEY", State = "ZZ", Zip5 = "98101" },
                    //  new AddressRequest {  Id = "1", StreetAddress = "23 RES LLORENS TORRES", City = "SAN JUAN", State = "PR", Zip5 =  "00924" },
                    //new AddressRequest { Id = "4", StreetAddress = "CMR 456 BOX 154", City = "APO", State = "AA"},
                    //new AddressRequest { Id = "5", StreetAddress = "2000 Tonnelle Ave", City = "North Bergen", State = "NJ"}
            }
            }).Result;
            string resul = result.AddressResponses[0].HasError ? "Not Verified" : "Verified";
            Console.WriteLine("Address verify result : " + resul);

            eVSLabelRequest eVSReq = new eVSLabelRequest();
            //General settings
            eVSReq.AllowNonCleansedDestAddr = true;
            eVSReq.AllowNonCleansedOriginAddr = true;
            eVSReq.ServiceType = AM.USPSLib.ServiceType.PRIORITY_EXPRESS;
            eVSReq.Container = Container.FLAT_RATE_ENVELOPE;
            //eVSReq.ShipDate = DateTime.Today;
            eVSReq.ReceiptOption = ReceiptOption.SEPARATE_PAGE;
            eVSReq.WeightInOunces = "48";
            eVSReq.SenderName = "USAA";
            eVSReq.ImageType = ImageType.PDF;
            eVSReq.LabelParameters = new LabelParameters()
            {
                Sequence = new LabelSequence() { PackageNumber = 1, TotalPackages = 1 },
                Size = LabelSize.SEPARATECONTINUEPAGE
            };
            eVSReq.ReturnCommitments = true;

            // From Address
            eVSReq.FromName = "Joe Smith";
            eVSReq.FromFirm = "ABC Corp.";
            eVSReq.FromAptOrSuiteorOther = "Apt. 3C";
            eVSReq.FromStreetAddress = "6406 Ivy Lane";
            eVSReq.FromCity = "Greenbelt";
            eVSReq.FromState = "MD";
            eVSReq.FromZip4 = "1234";
            eVSReq.FromZip5 = "20770";
            eVSReq.FromPhone = "5708208072";// new string('0', 10);

            // To Address
            eVSReq.ToFirm = "Tom Collins";
            eVSReq.ToName = "XYZ Corp.";
            eVSReq.ToAptOrSuiteorOther = "Suite 4D";
            eVSReq.ToStreetAddress = "8 Wildwood Drive";
            eVSReq.ToCity = "Old Lyme";
            eVSReq.ToState = "CT";
            eVSReq.ToZip4 = "";
            eVSReq.ToZip5 = "06371";
            eVSReq.ToPhone = new string('0', 10);

            //eVSReq.eVSCustomsFormsData = new eVSCustomsFormsData() { ShippingContents = new List<ItemDetail>() { new ItemDetail() { HSTariffNumber = "490110", CountryOfOrigin = "United States", Description = "Loan Document", Quantity = 1, NetPounds = 2, NetOunces = 0, Value = 50 } }, CustomsContentType = CustomsContentType.DOCUMENTS };
            //var eVSReq = D5();
            var res = svc.RequesteVSLabelAsync(eVSReq).Result;
            if (!string.IsNullOrWhiteSpace(res.BarcodeNumber))
            {
                Byte[] bytes = Convert.FromBase64String(res.LabelImageString);
                File.WriteAllBytes(@"Label.pdf", bytes);
                //bytes = Convert.FromBase64String(res.ReceiptImageString);
                //File.WriteAllBytes(@"Receipt.pdf", bytes);
            }
            Console.WriteLine(string.IsNullOrWhiteSpace(res.BarcodeNumber) ? "Label Not Generated" : "Label generated. You can find Label.pdf in same folder as exe");
            //Console.WriteLine(string.IsNullOrWhiteSpace(res.BarcodeNumber) ? "Receipt Not Generated" : "Receipt generated. You can find Label.pdf in same folder as exe");
            Console.WriteLine("press any key to close.");
            Console.Read();
        }

        public static eVSLabelRequest GetDefaultValue(bool military)
        {
            eVSLabelRequest eVSReq = new eVSLabelRequest();
            //General settings
            eVSReq.AllowNonCleansedDestAddr = true;
            eVSReq.AllowNonCleansedOriginAddr = true;
            eVSReq.ServiceType = AM.USPSLib.ServiceType.PRIORITY_EXPRESS;
            eVSReq.Container = Container.FLAT_RATE_ENVELOPE;
            eVSReq.ShipDate = DateTime.Now.Date;
            eVSReq.ReceiptOption = ReceiptOption.SEPARATE_PAGE;
            eVSReq.WeightInOunces = "48";
            eVSReq.SenderName = "USAA";
            eVSReq.ImageType = ImageType.PDF;
            eVSReq.LabelParameters = new LabelParameters()
            {
                Sequence = new LabelSequence() { PackageNumber = 1, TotalPackages = 1 },
                Size = LabelSize.SEPARATECONTINUEPAGE
            };
            eVSReq.ReturnCommitments = true;

            // From Address
            eVSReq.FromName = "USAA Federal Savings Bank";
            eVSReq.FromFirm = "USAA Federal Savings Bank";
            eVSReq.FromStreetAddress = "10750 McDermott Freeway";
            eVSReq.FromCity = "San Antonio";
            eVSReq.FromState = "TX";
            eVSReq.FromZip4 = "";
            eVSReq.FromZip5 = "78288";
            eVSReq.FromPhone = new string('0', 10);
            eVSReq.POZipCode = "75099";

            if (military)
            {
                eVSReq.eVSCustomsFormsData = new eVSCustomsFormsData()
                {
                    ShippingContents = new List<ItemDetail>() 
                    { 
                        new ItemDetail() { 
                            Description = "Loan Document", 
                            Quantity = 1, 
                            Value = 10,
                            NetPounds = 3, 
                            NetOunces = 0, 
                            CountryOfOrigin = "United States"
                        }
                    },
                    CustomsContentType = CustomsContentType.DOCUMENTS
                };
            }

            return eVSReq;
        }

        public static eVSLabelRequest D1()
        {
            eVSLabelRequest eVSReq = GetDefaultValue(true);
            eVSReq.ServiceType = ServiceType.PRIORITY;
            eVSReq.ToFirm = "";
            eVSReq.ToName = "LORI BAY";
            eVSReq.ToStreetAddress = "C/O RENEE REED  BOX 341";
            eVSReq.ToCity = "DPO";
            eVSReq.ToState = "AE";
            eVSReq.ToZip5 = "09831";
            eVSReq.CustomerRefNo = "D1";
            eVSReq.ToZip4 = "";
            eVSReq.ToPhone = new string('0', 10);

            return eVSReq;
        }
        public static eVSLabelRequest D2()
        {
            eVSLabelRequest eVSReq = GetDefaultValue(true);

            eVSReq.ToFirm = "";
            eVSReq.ToName = "N1";
            eVSReq.ToStreetAddress = "CMR 479 BOX 644";
            eVSReq.ToCity = "APO";
            eVSReq.ToState = "AE";
            eVSReq.ToZip5 = "09263";
            eVSReq.ToZip4 = "0007";
            eVSReq.CustomerRefNo = "N1";
            eVSReq.ToZip4 = "";
            eVSReq.ToPhone = new string('0', 10);

            return eVSReq;
        }
        public static eVSLabelRequest D3()
        {
            eVSLabelRequest eVSReq = GetDefaultValue(true);

            eVSReq.ToFirm = "";
            eVSReq.ToName = "N2";
            eVSReq.ToStreetAddress = "PSC 37 BOX 4298";
            eVSReq.ToCity = "APO";
            eVSReq.ToState = "AE";
            eVSReq.ToZip5 = "09459";
            eVSReq.ToZip4 = "0043";
            eVSReq.CustomerRefNo = "N2";
            eVSReq.ToZip4 = "";
            eVSReq.ToPhone = new string('0', 10);

            return eVSReq;
        }
        public static eVSLabelRequest D4()
        {
            eVSLabelRequest eVSReq = GetDefaultValue(true);
            eVSReq.ServiceType = ServiceType.PRIORITY;
            eVSReq.ToFirm = "";
            eVSReq.ToName = "William Cotten";
            eVSReq.ToStreetAddress = "PO BOX 3738";
            eVSReq.ToCity = "HAGATNA";
            eVSReq.ToState = "GU";
            eVSReq.ToZip5 = "96932";
            eVSReq.CustomerRefNo = "D4";
            eVSReq.ToZip4 = "";
            eVSReq.ToPhone = new string('0', 10);

            return eVSReq;
        }
        public static eVSLabelRequest D5()
        {
            eVSLabelRequest eVSReq = GetDefaultValue(false);
            eVSReq.ServiceType = ServiceType.PRIORITY;
            eVSReq.ToFirm = "";
            eVSReq.ToName = "Milan Patel";
            eVSReq.ToStreetAddress = "3 Akshardham Society Kisan Samosa lane";
            eVSReq.ToCity = "Nadiad";
            eVSReq.ToState = "GJ";
            eVSReq.ToZip5 = "387001";
            eVSReq.CustomerRefNo = "D5";
            eVSReq.ToZip4 = "";
            eVSReq.ToPhone = new string('0', 10);
            return eVSReq;
        }
        public static eVSLabelRequest D6()
        {
            eVSLabelRequest eVSReq = GetDefaultValue(true);
            //eVSReq.ServiceType = ServiceType.PRIORITY;
            eVSReq.POBox = true;
            eVSReq.ToFirm = "";
            eVSReq.ToName = "PASTORA RODRIGUEZ";
            eVSReq.ToStreetAddress = "PO BOX 10227";
            eVSReq.ToCity = "NAPLES";
            eVSReq.ToState = "FL";
            eVSReq.ToZip5 = "34101";
            eVSReq.CustomerRefNo = "D6";
            eVSReq.ToZip4 = "";
            eVSReq.ToPhone = new string('0', 10);

            return eVSReq;
        }
    }
}
